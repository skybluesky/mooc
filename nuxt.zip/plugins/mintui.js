import Vue from 'vue'
import mint from 'mint-ui'
import mintcss from 'mint-ui/lib/style.min.css'
Vue.use(mint)
Vue.use(mintcss)
