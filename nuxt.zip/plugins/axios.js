import Vue from 'vue'
import axios from 'axios'

Vue.prototype.$ajax = axios
