<template>
  <div id="tmp1">
    <div class='dw'>
    <div class='bg'></div>
    <div class='mb'>
      <div class='lr'>
        <img src="../static/bg5.jpg" alt="">
        <div class='btn' @click='play()'>
          <div :class='cals'></div>
          <div :class='cals2'></div>
        </div>
      </div>
      <div class='rb'>
        <div class='text' v-text='mid.name'></div>
        <div class='jdt'></div>
        <div class='jdt2'></div>
        <div class='jdt3'></div>
      </div>
      <span @click='next()'>
      </span>
    </div>
    </div>
    <audio :src="mid.url" ref='audios'>
    </audio>
  </div>
</template>
<script>
    export default {
      props:['mid'],
        data() {
            return {
              src:'',
              cals:'play',
              cals2:'',
              isplay:false
            }
        },
        created() {

        },
        beforeUpdate(){
          if(!this.isplay){
            this.cals = 'stop'
            this.cals2 = 'stop2'
            this.$refs.audio.play()
          }else {
            this.cals = 'play'
            this.cals2 = ''
            this.$refs.audio.paused()
          }
        },
        methods: {
          play(){
              if(!this.isplay){
                  this.cals = 'stop'
                  this.cals2 = 'stop2'
                this.$refs.audio.play()
              }else {
                this.cals = 'play'
                this.cals2 = ''
                this.$refs.audio.paused()
              }
          },
          next(){

          }
        },
        computed:{
          music(){
            return this.$store.state.music
          }
        }


    }
</script>
<style scoped>
  audio{
    width: 0;
  }
  #tmp1 {
    padding-top: 0.65rem;
    padding-bottom:1.2rem;
    width: 100%;
  }
  #tmp1 span{
    width: 0.8rem;
    height: 0.8rem;
    position: absolute;
    right: 0.2rem;
    top: 0%;
    text-align: center;
    padding-top: 0.2rem;
  }
  #tmp1 span::after,#tmp1 span::before{
    content: ' ';
    display: inline-block;
    width: 0;
    border: 0.15rem solid #000;
    border-color: transparent transparent transparent #6a6a6a;
  }
  .dw {
    position: relative;
  }
  .mb{
    position: absolute;
    left: 5%;
    top: 0;
    height: 0.8rem;
    width: 90%;
    border-radius: 0.1rem ;
  }
  .lr {
    width: 1.2rem;
    height: 0.8rem;
    text-align: center;
    line-height: 0.8rem ;
    float: left;
    position: relative;
  }
  .rb{
    margin-left: 1.2rem;
    margin-right: 1rem;
    height: 100%;
    position: relative;
  }
  .lr>img{
    display: inline-block;
    width: 0.7rem;
    height: 0.7rem;
    border-radius: 100%;
    margin-top: 0.05rem;
  }
  .paly{
    display: inline-block;
    position: absolute;
    z-index: 3;
    border: 0.15rem solid #000;
    width: 0;
    height: 0;
    top: 50%;
    left:50%;
    margin-top: -0.15rem;
    margin-left: -0.05rem;
    border-color:  transparent transparent transparent #6a6a6a;
  }
  .stop {
    display: inline-block;
    position: absolute;
    z-index: 3;
    width: 0;
    height: 0.3rem;
    border-left: 0.08rem solid #6a6a6a;
    margin-left:-0.075rem;
    top: 17%;
  }
  .stop2{
    display: inline-block;
    position: absolute;
    z-index: 3;
    width: 0;
    height: 0.3rem;
    margin-left:0.025rem;
    top: 17%;
    border-left: 0.08rem solid #6a6a6a;
  }
  .btn {
    width: 0.45rem;
    height: 0.45rem;
    position: absolute;
    left: 30%;
    top: 25%;
  }
  .jdt,.jdt2,.jdt3{
    position: absolute;
    width: 80%;
    top:50%;
  }
  .jdt{
    background-color: #696969;
    height: 5px;
    border-radius: 2px;
  }
  .rb .text {
    font-size: 15px;
    color: #fff;
    width: 80%;
  }

  .qqq{
    font-size: 20px;
    position: absolute;
    top: 30px;
    left: 30px;
  }
  .bg{
    height: 0.8rem;
    width: 90%;
    margin:0 5%;
    border-radius: 0.1rem ;
    -webkit-filter: blur(1px);
    background: url('../static/bg3.jpg');
    filter: blur(1px);
    background-size: 100% 0.8rem;
  }
</style>
