import Vue from 'vue'
import mint from 'mint-ui'
Vue.use(mint)

