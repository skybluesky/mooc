/**
 * Created by skychen on 2017/8/26.
 */
export default {
  url: 'http://172.20.10.3:3111'
}
