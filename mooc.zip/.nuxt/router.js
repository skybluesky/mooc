import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _798b51ae = () => import('..\\pages\\index.vue' /* webpackChunkName: "pages\\index" */).then(m => m.default || m)
const _1f33c83e = () => import('..\\pages\\music\\index.vue' /* webpackChunkName: "pages\\music\\index" */).then(m => m.default || m)
const _4796c271 = () => import('..\\pages\\aplay.vue' /* webpackChunkName: "pages\\aplay" */).then(m => m.default || m)
const _1620ff75 = () => import('..\\pages\\music\\play.vue' /* webpackChunkName: "pages\\music\\play" */).then(m => m.default || m)
const _ea05c6f8 = () => import('..\\pages\\music\\play-btn.vue' /* webpackChunkName: "pages\\music\\play-btn" */).then(m => m.default || m)



const scrollBehavior = (to, from, savedPosition) => {
  // SavedPosition is only available for popstate navigations.
  if (savedPosition) {
    return savedPosition
  } else {
    let position = {}
    // If no children detected
    if (to.matched.length < 2) {
      // Scroll to the top of the page
      position = { x: 0, y: 0 }
    }
    else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
      // If one of the children has scrollToTop option set to true
      position = { x: 0, y: 0 }
    }
    // If link has anchor, scroll to anchor by returning the selector
    if (to.hash) {
      position = { selector: to.hash }
    }
    return position
  }
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/",
			component: _798b51ae,
			name: "index"
		},
		{
			path: "/music",
			component: _1f33c83e,
			name: "music"
		},
		{
			path: "/aplay",
			component: _4796c271,
			name: "aplay"
		},
		{
			path: "/music/play",
			component: _1620ff75,
			name: "music-play"
		},
		{
			path: "/music/play-btn",
			component: _ea05c6f8,
			name: "music-play-btn"
		}
    ],
    fallback: false
  })
}
